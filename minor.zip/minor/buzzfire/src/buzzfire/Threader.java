package buzzfire;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.http.HttpSession;

public class Threader {
	objcall s=new objcall();
	  repo o=s.getobj();
		   public void remove()
			{
				 int index = objcall.l.size() - 1; 
				 repo r=s.getobj();
			        objcall.l.remove(index);
			        System.out.println("Am i running?");
			        
			        String Uid="root";
			        String password="root";
			        String DB_URL="jdbc:mysql://localhost:3306/buzzfire";
			        String query="delete from repocon where head='"+r.geth()+"' ;";
			        String query1="insert into reports  (id,head,cont,winner) select id,head,cont,bidder from repocon where head='"+r.geth()+"' ;";
			        try {
			        	Class.forName("com.mysql.jdbc.Driver");
					    Connection con= DriverManager.getConnection(DB_URL,Uid,password);				        
				        System.out.println("quert 1 [rbl,");
				        Statement stmt1=con.createStatement();
				        int rs1=stmt1.executeUpdate(query1);
				        
				        System.out.println("updated reports");
				        Statement stmt=con.createStatement();
				        int rs=stmt.executeUpdate(query);
				        System.out.println("deleted");
				     System.out.println(rs+" "+rs1);			      
				        stmt.close();
				        con.close();			        
				        System.out.println("done");
			        }		    
			        catch (ClassNotFoundException e) {
						//  Auto-generated catch block
			        	System.out.println("query not working");
						e.printStackTrace();
					} catch (SQLException e) {
						//  Auto-generated catch block
						e.printStackTrace();
					}
			        catch(Exception e)
			        {
			        	e.printStackTrace();
			        }
				}
			

		   public static void main(String[] args) {
			   Threader t=new Threader();
			   
			   t.remove();
		   
		/*   runmethod t=new runmethod();
			 Thread f=new Thread(t);
		f.start();
		try {
			Thread.sleep(60000);
			
			objcall o=new objcall();
	        System.out.println("//////////1");
	        o.print();
	        System.out.println("//////////2");
	       // repo r=o.getobj();
			t.remove();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		*/
	}
}

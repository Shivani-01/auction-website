package buzzfire;

import java.util.ArrayList;

 public class objcall {
	 public static ArrayList<repo> l = new ArrayList<>();
	 	 
	 public void setobj(repo o)
	 {
		 l.add(o);
	 }
	 
	   public repo getobj()
	   {
		   return l.get(l.size() - 1);
	   }
	   
	   public void print()
	   {
		   for (int i=0; i<l.size(); i++) 
	            System.out.println(l.get(i)+" "); 
	   }
}


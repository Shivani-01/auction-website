package buzzfire;

import java.io.IOException;

public class check implements Runnable{
	 		public void run()
		{		
				   System.out.println("I'm check");
				   System.out.println("Am i working parallely");
				   String url_open ="http://localhost:8080/buzzfire/sucess.html";
				   try {
					java.awt.Desktop.getDesktop().browse(java.net.URI.create(url_open));
				} catch (IOException e) {			
					e.printStackTrace();
				}
		}	
}

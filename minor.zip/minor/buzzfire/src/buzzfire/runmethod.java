package buzzfire;

public class runmethod implements Runnable{
	objcall s=new objcall();
	  repo o=s.getobj();
	 		public void run()
		{		System.out.println("I'm runmethod");
				   objcall.l.add(o);
				   System.out.println(objcall.l.size() +"is size of arraylist");
				   
				   
				 			   
				   
				   }
		}	
		       
		
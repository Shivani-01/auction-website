package buzzfire;
import java.util.*;
public class hm 
{
    static HashMap< String , String> hm1 = new HashMap< String , String>();     
	public void seth(String s,String i)
	{
		
		hm1.put(s, i);
	}	
	public boolean chckh(String s,String i)
	{
		hm1.put("shivi", "0206");
		System.out.println(hm1.get(s));
		if(i==hm1.get(s))
			return true;
		else
			return false;
	}
}
